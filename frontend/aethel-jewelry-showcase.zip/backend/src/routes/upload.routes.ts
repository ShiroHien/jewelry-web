// FIX: Import Request to correctly type the fileFilter callback parameter.
import express, { Request } from 'express';
import multer from 'multer';
import path from 'path';
import { protect } from '../middleware/auth.middleware';
import { uploadImage } from '../controllers/upload.controller';

const router = express.Router();

// Set up multer for file storage in memory
const storage = multer.memoryStorage();

const upload = multer({ 
    storage,
    // FIX: Add Request type to req parameter to ensure type compatibility.
    fileFilter: function (req: Request, file, cb) {
        const filetypes = /jpeg|jpg|png|gif/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        if (mimetype && extname) {
            return cb(null, true);
        }
        cb(new Error('Error: File upload only supports the following filetypes - ' + filetypes));
    }
});

// FIX: The "No overload" error on this line is resolved by fixing the handler types above.
router.post('/', protect, upload.single('image'), uploadImage);

export default router;