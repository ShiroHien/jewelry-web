// FIX: Explicitly import Request and Response to avoid type conflicts with global types.
import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './config/db';
import authRoutes from './routes/auth.routes';
import productRoutes from './routes/product.routes';
import blogRoutes from './routes/blog.routes';
import uploadRoutes from './routes/upload.routes';

// Load environment variables from .env file
dotenv.config();

// Connect to Database
connectDB();

const app = express();
const port = process.env.PORT || 3001;

// Middlewares
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // To parse JSON bodies

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/blog', blogRoutes);
// FIX: The overload error on this line is resolved by fixing the signatures of the handlers used within the router.
app.use('/api/upload', uploadRoutes);


// A simple test route to make sure the server is running
// FIX: Use explicit Request and Response types from express to resolve property 'send' not existing.
app.get('/', (req: Request, res: Response) => {
  res.send('Aethel Jewelry Backend is running!');
});

app.listen(port, () => {
  console.log(`[server]: Server is running at http://localhost:${port}`);
});